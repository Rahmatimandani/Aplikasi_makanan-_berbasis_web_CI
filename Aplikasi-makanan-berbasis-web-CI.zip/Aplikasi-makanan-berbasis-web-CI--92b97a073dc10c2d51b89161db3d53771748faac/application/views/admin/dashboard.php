<section class="content container-fluid">

      <div class="row">
        <div class="col-md-12 col-lg-6">
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="fa fa-file"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Resep</span>
              <span class="info-box-number"><?php echo $resep?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-12 col-lg-6">
          <div class="info-box">
            <span class="info-box-icon bg-red"><i class="fa fa-users"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Komentar</span>
              <span class="info-box-number"><?php echo $komen?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->

        <!-- fix for small devices only -->
        <div class="clearfix visible-sm-block"></div>
      </div>

    </section>
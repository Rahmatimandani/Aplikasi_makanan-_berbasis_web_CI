# Aplikasi-makanan-berbasis-web-CI-
Aplikasi Resep Makanan Berbasis Web adalah sebuah sistem informasi resep yang dibangun dan digunakan untuk memudahkan dalam memberikan informasi resep makanan. Aplikasi ini dilengkapi dengan fitur login admin, data resep, data kategori, data komentar dan lain sebagainya.
